//
//  TimeViewController.swift
//  UnitConverter
//

import UIKit
import Firebase

class TimeViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var hourField :  UITextField!
    @IBOutlet weak var minField :  UITextField!
    @IBOutlet weak var secField :  UITextField!
    @IBOutlet weak var msecField :  UITextField!
    
    let timeConverter = TimeConverter()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboard()
        self.hourField.delegate = self
        self.minField.delegate = self
        self.secField.delegate = self
        self.msecField.delegate = self
        // Do any additional setup after loading the view.
    }
    @IBAction func hourConversion(sender : UITextField){
        let value = sender.text!
        
        if(!value.isEmpty){
            
            let d = Double(value)
            let min = timeConverter.greaterToSmaller(value: d!)
            let sec = timeConverter.greaterToSmaller(value:min)
            let micro = timeConverter.greaterToMilliseconds(value: sec)
            
            minField.text = String(min)
            secField.text = String(sec)
            msecField.text = String(micro)
            self.saveValues()
        }else{
            resetFields()
        }
    }
    @IBAction func minConversion(sender : UITextField){
        let value = sender.text!
        
        if(!value.isEmpty){
            
            let d = Double(value)
            let hour = timeConverter.smallerToGreater(value: d!)
            let sec = timeConverter.greaterToSmaller(value:d!)
            let micro = timeConverter.greaterToSmaller(value:sec)
            
            hourField.text = String(hour)
            secField.text = String(sec)
            msecField.text = String(micro)
            self.saveValues()
        }else{
            resetFields()
        }
    }
    @IBAction func secConversion(sender : UITextField){
        let value = sender.text!
        
        if(!value.isEmpty){
            
            let d = Double(value)
            let min = timeConverter.smallerToGreater(value: d!)
            let hour = timeConverter.smallerToGreater(value: min)
            let micro = timeConverter.greaterToSmaller(value:d!)
            
            hourField.text = String(hour)
            minField.text = String(min)
            msecField.text = String(micro)
            self.saveValues()
        }else{
            resetFields()
        }
    }
    @IBAction func msecConversion(sender : UITextField){
        let value = sender.text!
        
        if(!value.isEmpty){
            
            let d = Double(value)
            let sec = timeConverter.smallerToGreater(value: d!)
            let min = timeConverter.smallerToGreater(value: sec)
            let hour = timeConverter.smallerToGreater(value: min)
            
            hourField.text = String(hour)
            minField.text = String(min)
            secField.text = String(sec)
            self.saveValues()
        }else{
            resetFields()
        }
    }
    func resetFields(){
        minField.text = ""
        msecField.text = ""
        secField.text = ""
        
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string.isEmpty { return true }
        
        let currentText = textField.text ?? ""
        let replacementText = (currentText as NSString).replacingCharacters(in: range, with: string)
        
        return replacementText.isValidDouble(maxDecimalPlaces: 4)
    }
    
    private func saveValues() {
        // For Create Values to Store in firestore: -
        let db = Firestore.firestore()
    
        db.collection("valuesTimeVC").addDocument(data: ["hour": hourField.text!, "minutes": minField.text!,"seconds": secField.text!, "milliseconds": msecField.text!]) { (error) in
            if error != nil {
                AlertController.showAlert(self, title: "Not Found", message: error!.localizedDescription)
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
