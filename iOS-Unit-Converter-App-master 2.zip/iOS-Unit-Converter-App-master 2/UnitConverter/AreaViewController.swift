//
//  AreaViewController.swift
//  UnitConverter
//

import UIKit
import Firebase

class AreaViewController: UIViewController,UITextFieldDelegate {


          @IBOutlet var sfTextField: UITextField!
          @IBOutlet var syTextField: UITextField!
          @IBOutlet var smTextField: UITextField!
          
          let areaConverter = AreaConverter()
          
          override func viewDidLoad() {
              super.viewDidLoad()
              self.hideKeyboard()
              
              self.sfTextField.delegate = self
              self.syTextField.delegate = self
              self.smTextField.delegate = self
          }
    @IBAction func sfToAll(sender:UITextField){
        let value = sender.text!
        
        if(!value.isEmpty){
            
            let d = Double(value)
            let sm = areaConverter.sftosm(value: d!)
            let sy = areaConverter.sftosy(value: d!)
            
            smTextField.text = String(sm)
            syTextField.text = String(sy)
            self.saveValues()
        }else{
            resetFields()
        }
    }
    @IBAction func smToAll(sender:UITextField){
           let value = sender.text!
           
           if(!value.isEmpty){
               
               let d = Double(value)
               let sf = areaConverter.smtosf(value: d!)
               let sy = areaConverter.smtosy(value: d!)
               
               sfTextField.text = String(sf)
               syTextField.text = String(sy)
               self.saveValues()
           }else{
               resetFields()
           }
   }
    @IBAction func syToAll(sender:UITextField){
           let value = sender.text!
           
           if(!value.isEmpty){
               
               let d = Double(value)
               let sm = areaConverter.sytosm(value: d!)
               let sf = areaConverter.sytosf(value: d!)
               smTextField.text = String(sm)
               syTextField.text = String(sf)
                self.saveValues()
           }else{
               resetFields()
           }
   }
   func resetFields(){
       smTextField.text = ""
       syTextField.text = ""
       sfTextField.text = ""
   }
   func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
       if string.isEmpty { return true }
       
       let currentText = textField.text ?? ""
       let replacementText = (currentText as NSString).replacingCharacters(in: range, with: string)
       
       return replacementText.isValidDouble(maxDecimalPlaces: 4)

    }
    private func saveValues() {
        // For Create Values to Store in firestore: -
        let db = Firestore.firestore()
    
        db.collection("valuesAreaVC").addDocument(data: ["squareFeet": sfTextField.text!, "squareYard": syTextField.text!,"squareMeter": smTextField.text!]) { (error) in
            if error != nil {
                AlertController.showAlert(self, title: "Not Found", message: error!.localizedDescription)
            }
        }
    }
}
