//
//  AngleViewController.swift
//  UnitConverter
//

import UIKit
import Firebase

class AngleViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var degreeTextField : UITextField!
    
    @IBOutlet weak var radTextField : UITextField!
    
   let angleConverter = AngleConverter()
    
   override func viewDidLoad() {
       super.viewDidLoad()
       // Do any additional setup after loading the view, typically from a nib.
       // hide decimal pad
        self.hideKeyboard()
        degreeTextField.resignFirstResponder()
        radTextField.resignFirstResponder()
        self.degreeTextField.delegate = self
        self.radTextField.delegate = self

     //   fetchData()

   }
    
//    override func viewDidAppear(_ animated: Bool) {
//        super.viewDidAppear(animated)
//        fetchData()
//    }
    
//    override func viewDidDisappear(_ animated: Bool) {
//        super.viewDidDisappear(animated)
//        fetchData()
//    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.fetchData()
        }
        
    }
    

  
   override func didReceiveMemoryWarning() {
       super.didReceiveMemoryWarning()
       // Dispose of any resources that can be recreated.
   }
   
//    func fetchAngleValues() {
//        // Retrive Values: -
//        let db = Firestore.firestore()
//        db.collection("values").getDocuments { (snapshot, error) in
//            if error != nil {
//                      print("Error")
//                  } else {
//                      for value in (snapshot?.documents)! {
//                          print(value.data())
//                        value.data()
//                        self.degreeTextField.text = value.data()
//                        self.radTextField.text = "hr"//value.data()
//                      }
//                  }
//            }
//    }
    
    
   private func fetchData() {
        let db = Firestore.firestore()
        db.collection("angle").addSnapshotListener { (snapshot, error) in
            guard let snapShot = snapshot else {
                print("error")
                return
            }
            
            for document in snapShot.documents{
                print(document.data())
                let array = document.data()
                let radianValue = array["radian"]
                let degreeValue = array["degree"]
                self.radTextField.text = radianValue as? String
                self.degreeTextField.text = degreeValue as? String
             //   print("RadianVAlue:", radianValue)
             //   self.degreeTextField.text = document.data()
                
             //   self.degreeTextField.text = document.data() as? String
            }
        }
    }
    
   @IBAction func degChanged(_ sender: UITextField) {
       let value = sender.text!
       
       if(!value.isEmpty){
           
           let d = Double(value)
        let values = angleConverter.DegToRad(deg: d!)
        radTextField.text = String(values)
        self.saveValues()
         
       }else{
           resetFields()
       }
   }
   @IBAction func radChanged(_ sender: UITextField) {
       let value = sender.text!
       
       if(!value.isEmpty){
           
           let d = Double(value)
        let values = angleConverter.radToDeg(rad: d!)
        degreeTextField.text = String(values)
        self.saveValues()
         
       }else{
           resetFields()
       }
   }
    func resetFields(){
        degreeTextField.text = ""
        radTextField.text = ""
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string.isEmpty { return true }
        
        let currentText = textField.text ?? ""
        let replacementText = (currentText as NSString).replacingCharacters(in: range, with: string)
        
        return replacementText.isValidDouble(maxDecimalPlaces: 4)
    }
    
    private func saveValues() {
        // For Create Values to Store in firestore: -
        let db = Firestore.firestore()
    
        db.collection("angle").addDocument(data: ["degree": degreeTextField.text!, "radian": radTextField.text!]) { (error) in
            if error != nil {
                AlertController.showAlert(self, title: "Not Found", message: error!.localizedDescription)
            }
        }
    }

}
