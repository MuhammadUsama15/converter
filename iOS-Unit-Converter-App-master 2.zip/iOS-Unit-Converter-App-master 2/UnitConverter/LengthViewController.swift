//
//  LengthViewController.swift
//  UnitConverter
//

import UIKit
import Firebase

class LengthViewController: UIViewController,UITextFieldDelegate {
       @IBOutlet var mTextField: UITextField!
       @IBOutlet var cmTextField: UITextField!
       @IBOutlet var mmTextField: UITextField!
       @IBOutlet var iTextField: UITextField!
       
       let lengthConverter = LengthConverter()
       
       override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view, typically from a nib.
           
           // hide keyboard
           self.hideKeyboard()
           
           self.mTextField.delegate = self
           self.cmTextField.delegate = self
           self.mmTextField.delegate = self
           self.iTextField.delegate = self
       }
    @IBAction func meterTo(sender : UITextField){
        let value = sender.text!
        
        if(!value.isEmpty){
            
            let d = Double(value)
            let cm = lengthConverter.meterTocm(value: d!)
            let mm = lengthConverter.meterTomm(value: d!)
            let inch = lengthConverter.meterToinch(value: d!)
            
            cmTextField.text = String(cm)
            mmTextField.text = String(mm)
            iTextField.text = String(inch)
            self.saveValues()
        }else{
            resetFields()
        }
    }
    @IBAction func inchTo(sender : UITextField){
        let value = sender.text!
        
        if(!value.isEmpty){
            
            let d = Double(value)
            let cm = lengthConverter.inchTocm(value: d!)
            let mm = lengthConverter.inchTomm(value: d!)
            let m = lengthConverter.inchTometer(value: d!)
            cmTextField.text = String(cm)
            mmTextField.text = String(mm)
            mTextField.text = String(m)
            self.saveValues()
        }else{
            resetFields()
        }
    }
    @IBAction func mmTo(sender : UITextField){
        let value = sender.text!
        
        if(!value.isEmpty){
            
            let d = Double(value)
            let inch = lengthConverter.mmToinch(value: d!)
            let cm = lengthConverter.mmTocm(value: d!)
            let m = lengthConverter.mmTom(value: d!)
            cmTextField.text = String(cm)
            iTextField.text = String(inch)
            mTextField.text = String(m)
            self.saveValues()
        }else{
            resetFields()
        }
    }
    @IBAction func cmTo(sender : UITextField){
        let value = sender.text!
        
        if(!value.isEmpty){
            
            let d = Double(value)
            let inch = lengthConverter.cmToinch(value: d!)
            let mm = lengthConverter.cmTomm(value: d!)
            let m = lengthConverter.cmTom(value: d!)
            mmTextField.text = String(mm)
            iTextField.text = String(inch)
            mTextField.text = String(m)
            self.saveValues()
        }else{
            resetFields()
        }
    }

    func resetFields(){
        iTextField.text = ""
        mTextField.text = ""
        mmTextField.text = ""
        cmTextField.text = ""
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string.isEmpty { return true }
        
        let currentText = textField.text ?? ""
        let replacementText = (currentText as NSString).replacingCharacters(in: range, with: string)
        
        return replacementText.isValidDouble(maxDecimalPlaces: 4)
    }

    private func saveValues() {
        // For Create Values to Store in firestore: -
        let db = Firestore.firestore()
    
        db.collection("valuesLengthVC").addDocument(data: ["Meter": mTextField.text!, "Centimeter": cmTextField.text!,"Millimeter": mmTextField.text!, "inches": iTextField.text!]) { (error) in
            if error != nil {
                AlertController.showAlert(self, title: "Not Found", message: error!.localizedDescription)
            }
        }
    }
    
}
