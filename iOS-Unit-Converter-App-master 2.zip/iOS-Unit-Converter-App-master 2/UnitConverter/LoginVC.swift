//
//  LoginVC.swift
//  UnitConverter
//
//  Created by Macbook Air on 2/7/21.
//  Copyright © 2021 tutorial. All rights reserved.
//

import UIKit
import Firebase

class LoginVC: UIViewController {

    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var emailTxtField: UITextField! {
        didSet {
            let whitePlaceholderText = NSAttributedString(string: "Enter Email", attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
                    
                    emailTxtField.attributedPlaceholder = whitePlaceholderText
        }
    }
   
    @IBOutlet weak var passwordTxtField: UITextField! {
        didSet {
            let whitePlaceholderText = NSAttributedString(string: "Enter Password", attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
                    
                    passwordTxtField.attributedPlaceholder = whitePlaceholderText
        }
    }
    
  //  @IBOutlet weak var loginFacebookBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let loginButton = FBLoginButton()
//        loginButton.center = view.center
//        view.addSubview(loginButton)
//
        setupElements()
        loginBtn.layer.cornerRadius = 15
//        addImgLeft(textField: emailTxtField, For: UIImage(named: "Email")!)
//        addImgLeft(textField: passwordTxtField, For: UIImage(named: "Password")!)
//        
       
    }
    
    func setupElements() {
        Styling.styleTextField(emailTxtField)
        Styling.styleTextField(passwordTxtField)
    }
    
    func addImgLeft(textField: UITextField, For image: UIImage) {
        let leftImageView = UIImageView(frame: CGRect(x: 0.0, y: 0.0, width: image.size.width/2, height: image.size.height/2))
        leftImageView.image = image
        textField.leftView = leftImageView
        textField.leftViewMode = .always
    }
    
    
    @IBAction func didLoginWithFacebookTap(_ sender: Any) {
    }
    
    @available(iOS 13.0, *)
    @IBAction func didLoginTap(_ sender: Any) {
        
        print("Login Tap")
        // Validate Textfields: -
        guard let email = emailTxtField.text,
              email != "",
              let password = passwordTxtField.text,
              password != ""
        else {
            AlertController.showAlert(self, title: "Missing fields", message: "Please fill in all the fields")
            return
            print("Fields are missing")
        }
        
        // Sign in Authenticate users: -
        Auth.auth().signIn(withEmail: email, password: password) { (result, err) in
            // if there's no authenticate user: -
            if err != nil {
                AlertController.showAlert(self, title: "Incorrect email or password", message: "Please enter the correct email and password")
            }
            else {
            // User Successfully sign in: -
                let db = Firestore.firestore()
                
                db.collection("users00").addDocument(data: [ "email": email, "[password]": password ]) { (error) in
                    
                    // Error: -
                    if error != nil {
                        AlertController.showAlert(self, title: "User name could not found", message: error!.localizedDescription)
                    }
                 
                }
                //Successfully
                if #available(iOS 13.0, *) {
                    self.transitionTohome()
                } else {
                    // Fallback on earlier versions
                    print("Failed")
                }
            }
    
        }
    }
    
    @available(iOS 13.0, *)
    func transitionTohome() {
 
        let homeViewController = storyboard?.instantiateViewController(identifier: Transition.Storyboard.homeVC) as? HomeCollectionViewController
        view.window?.rootViewController = homeViewController
        view.window?.makeKeyAndVisible()
    }



}
