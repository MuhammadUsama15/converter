//
//  CollectionViewController.swift
//  UnitConverter
//

import UIKit

class HomeCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell1 = collectionView.dequeueReusableCell(withReuseIdentifier: "cell1", for: indexPath)
        let cell2 = collectionView.dequeueReusableCell(withReuseIdentifier: "cell2", for: indexPath)
        let cell3 = collectionView.dequeueReusableCell(withReuseIdentifier: "cell3", for: indexPath)
        let cell4 = collectionView.dequeueReusableCell(withReuseIdentifier: "cell4", for: indexPath)
        let cell5 = collectionView.dequeueReusableCell(withReuseIdentifier: "cell5", for: indexPath)
        let cell6 = collectionView.dequeueReusableCell(withReuseIdentifier: "cell6", for: indexPath)
        let cell7 = collectionView.dequeueReusableCell(withReuseIdentifier: "cell7", for: indexPath)
        let cell8 = collectionView.dequeueReusableCell(withReuseIdentifier: "cell8", for: indexPath)
        
        if indexPath.item == 0 {
            return cell1

        }
        else if indexPath.item == 1 {
            return cell2
        }
        else if indexPath.item == 2 {
            return cell3
        }
        else if indexPath.item == 3 {
            return cell4
        }
        else if indexPath.item == 4 {
            return cell5
        }
        else if indexPath.item == 5 {
            return cell6
        }
        else if indexPath.item == 6 {
            return cell7
        }
        else {
            return cell8
        }
    }
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 8
    }
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView?.delegate = self
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        print("Called")
//        print(UIScreen.main.bounds.width / 2 - 100)
        return CGSize(width: view.safeAreaLayoutGuide.layoutFrame.width / 2 - 5, height: 190)
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.item == 0 {
            performSegue(withIdentifier: "angle", sender: nil)
        }
        if indexPath.item == 1 {
            performSegue(withIdentifier: "area", sender: nil)
        }
        else if indexPath.item == 2 {
            performSegue(withIdentifier: "length", sender: nil)
        }
        else if indexPath.item == 3{
            performSegue(withIdentifier: "time", sender: nil)
}
        else if indexPath.item == 4 {
            performSegue(withIdentifier: "temp", sender: nil)
        }
        else if indexPath.item == 5 {
            performSegue(withIdentifier: "weight", sender: nil)
        }
        else if indexPath.item == 6 {
            performSegue(withIdentifier: "speed", sender: nil)
        }
        else if indexPath.item == 7 {
            performSegue(withIdentifier: "distance", sender: nil)
        }

    }

}
