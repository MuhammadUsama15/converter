//
//  Time.swift
//  UnitConverter
//
//  Created by Mac on 28/10/2019.
//  Copyright © 2019 tutorial. All rights reserved.
//
class TimeConverter
{
    let SecondsToMinutes = 60.0
    let MinutesToHours = 60.0
    let HoursToDays = 24.0
    let DaysToMonths = 30
    let MonthsToYears = 12.0
    
    func CalorieToJoule(calorie: Double) -> Double {
        return calorie * calorieToJoule
    }
    func BTUToJoule(BTU: Double) -> Double {
        return BTU * BTUToJoule
    }
    func BTUToCal(calorie: Double) -> Double {
        return calorie * calorieToJoule
    }
}
